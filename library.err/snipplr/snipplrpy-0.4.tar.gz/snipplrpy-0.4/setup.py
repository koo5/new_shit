#!/usr/bin/env python

from distutils.core import setup

setup (name = "SnipplrPy",
	version = "0.4",
	description = "Snipplr service xml-rpc wrapper",
	author = "Francisco Jesus Jordano Jimenez",
	author_email = "arcturus@ardeenelinfierno.com",
	url = "http://www.ardeenelinfierno.com/wordpress/code/snipplrpy/",
	py_modules = ["SnipplrPy"]
	)

